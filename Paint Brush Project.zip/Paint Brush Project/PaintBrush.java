// This is my prpject , I hope you like it , I know its not the most optimal and optimized code but i try to do my best
// All thanks for all staff , Eng Ahmed mazen , Eng Heba , Eng Hager
// Name : Ibrahim Ahmed Elnwasany 
//Track : DM Alex Branch
import java.applet.Applet;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;
import java.awt.BasicStroke;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Stroke;

//Object-oriented concepts used include encapsulation (grouping related variables and methods), inheritance (extending the Applet class), and polymorphism (calling drawShape on different shapes)

public class PaintBrush extends Applet {
     // Constants representing different drawing modes
	public static final int Rec = 1;
    public static final int Lin = 2;
    public static final int Ova = 3;
    public static final int Era = 4;
    public static final int Clc = 5;
    public static final int UNd = 6;
    public static final int Pen = 7;
	private static final int REDO =8;
	
// Variables for current mode, color, and drawing flags
    int Mode;
     boolean Flag = false;
	boolean solid = false;
    boolean dottedStroke = false;
    Color CurrentColor;
    Button rectangle;
    Button Line;
    Button Oval;
    Button Eraser;
	Button Pencil;
    Button Red;
    Button Black;
    Button Green;
    Button Blue;
    Button ClearAll;
    Button Undo;
	Button redo;
    Checkbox fill;
    Checkbox dotted;
    // Lists to store drawn shapes and redo operations

	ArrayList<GeoShape> ShapeList = new ArrayList<>();
	ArrayList<GeoShape> redoList = new ArrayList<>();

    
	// Variables for tracking mouse coordinates
	int X11, Y11, X22, Y22;

// Initialization method , UI components creation and setup ,Event listeners setup
   
    
	public void init() {
        rectangle = makeStyledButton("Rectangle");
        Line = makeStyledButton("Line");
        Oval = makeStyledButton("Oval");
        Eraser = makeStyledButton("Eraser");
		Pencil = makeStyledButton("Pencil");
        Red = makeStyledButton("Red");
         Blue = makeStyledButton("Blue");
		Green = makeStyledButton("Green");
        Black = makeStyledButton("Black");
        ClearAll = makeStyledButton("ClearAll");
        Undo = makeStyledButton("Undo");
        redo = makeStyledButton("Redo");	  

        fill = new Checkbox("Fill");
        fill.setFont(new Font("Arial", Font.BOLD, 24));
        fill.setBackground(Color.yellow);
        fill.setForeground(Color.black);
        fill.setSize(150, 30);
        setBackground(new Color(135, 206, 250));
        dotted = new Checkbox("Dotted");
        dotted.setFont(new Font("Arial", Font.BOLD, 24));
        dotted.setBackground(Color.yellow);
        dotted.setForeground(Color.black);
        dotted.setSize(150, 30);

      
        SolidCheck f = new SolidCheck();
        RecButton rec = new RecButton();
        LineButton lin = new LineButton();
        EraserButton era = new EraserButton();
        PencilButton pen = new PencilButton();
        OvalButton ova = new OvalButton();
        ClearAllButton clc = new ClearAllButton();
        UndoButton und = new UndoButton();
		RedoButton redoo = new RedoButton();
        RedColor r = new RedColor();
        GreenColor gre = new GreenColor();
        BlueColor blu = new BlueColor();
        BlackColor bla = new BlackColor();
        DottedCheckboxListener dottedListener = new DottedCheckboxListener();
        Press_Release p = new Press_Release();
        Drag d = new Drag();
       
	   
        fill.addItemListener(f);
        rectangle.addActionListener(rec);
        Oval.addActionListener(ova);
        Pencil.addActionListener(pen);
        Eraser.addActionListener(era);
        ClearAll.addActionListener(clc);
        Undo.addActionListener(und);
		redo.addActionListener(redoo);
        Line.addActionListener(lin);
        Red.addActionListener(r);
        Green.addActionListener(gre);
        Blue.addActionListener(blu);
        Black.addActionListener(bla);
        dotted.addItemListener(dottedListener);
        this.addMouseListener(p);
        this.addMouseMotionListener(d);
        
		add(rectangle);
        add(Oval);
        add(Line);
		add(Eraser);
        add(Pencil);
		add(ClearAll);
        add(Undo);
		add(redo);
        add(Red);
        add(Green);
        add(Blue);
        add(Black);
        add(fill);
        add(dotted);
    }

// Helper method to create styled buttons and also control all buttons   
   private Button makeStyledButton(String label) {
        Button button = new Button(label);
        button.setFont(new Font("Arial", Font.BOLD, 32));
        button.setBackground(Color.yellow);
        return button;
    }
// Paint method to render shapes on the applet
//Polymorphism
    public void paint(Graphics g) {
        for (GeoShape Shape : ShapeList) {
            Shape.drawShape(g);
        }
// Render the shape being currently drawn
        switch (Mode) {
            case Rec:
                (new RectangleShape(X11, Y11, X22, Y22, CurrentColor, solid, dottedStroke)).drawShape(g);
                break;
            case Lin:
                (new LineShape(X11, Y11, X22, Y22, CurrentColor, dottedStroke)).drawShape(g);
                break;
            case Ova:
                (new OvalShape(X11, Y11, X22, Y22, CurrentColor, solid, dottedStroke)).drawShape(g);
                break;
            case Era:
                (new EraserShape(X11, Y11, 15, 15, Color.white)).drawShape(g);
                break;
            case Pen:
                (new PencilShape(X11, Y11, 15, 15, CurrentColor)).drawShape(g);
                break;
        }
    }

//series of inner classes that implement ActionListeners for various buttons and ItemListeners for checkboxes
//Object-oriented concepts used here include encapsulation (grouping related functionality in classes), polymorphism (implementing different listeners), and event-driven programming (responding to user actions)
    class RecButton implements ActionListener {
        public void actionPerformed(ActionEvent ev) {
            Mode = Rec;
        }
    }

    class OvalButton implements ActionListener {
        public void actionPerformed(ActionEvent ev) {
            Mode = Ova;
        }
    }

    class LineButton implements ActionListener {
        public void actionPerformed(ActionEvent ev) {
            Mode = Lin;
        }
    }

    class EraserButton implements ActionListener {
        public void actionPerformed(ActionEvent ev) {
            Mode = Era;
        }
    }

    class PencilButton implements ActionListener {
        public void actionPerformed(ActionEvent ev) {
            Mode = Pen;
        }
    }
 class RedColor implements ActionListener {
        public void actionPerformed(ActionEvent ev) {
            CurrentColor = Color.red;
        }
    }

    class GreenColor implements ActionListener {
        public void actionPerformed(ActionEvent ev) {
            CurrentColor = Color.green;
        }
    }

    class BlueColor implements ActionListener {
        public void actionPerformed(ActionEvent ev) {
            CurrentColor = Color.blue;
        }
    }

    class BlackColor implements ActionListener {
        public void actionPerformed(ActionEvent ev) {
            CurrentColor = Color.black;
        }
    }
    class ClearAllButton implements ActionListener {
        public void actionPerformed(ActionEvent ev) {
            Mode = Clc;
            ShapeList.clear();
            repaint();
        }
    }

     class UndoButton implements ActionListener {
        public void actionPerformed(ActionEvent ev) {
            if (ShapeList.size() > 0) {
                redoList.add(ShapeList.remove(ShapeList.size() - 1));
                repaint();
            }
        }
    }

    class RedoButton implements ActionListener {
        public void actionPerformed(ActionEvent ev) {
            if (redoList.size() > 0) {
                ShapeList.add(redoList.remove(redoList.size() - 1));
                repaint();
            }
        }
    }


    class SolidCheck implements ItemListener {
        public void itemStateChanged(ItemEvent e) {
            solid = !solid;
        }
    }

    class DottedCheckboxListener implements ItemListener {
        public void itemStateChanged(ItemEvent e) {
            dottedStroke = dotted.getState();
        }
    }

    //Object-oriented concepts employed here include inheritance (with MouseMotionAdapter and MouseAdapter), polymorphism (through abstract methods in GeoShape), and encapsulation (grouping related mouse event handling in separate classes)
	class Drag extends MouseMotionAdapter {
        public void mouseDragged(MouseEvent e) {
            if (Mode == Pen) {
                X11 = e.getX();
                Y11 = e.getY();
                ShapeList.add(new PencilShape(X11, Y11,15,15, CurrentColor));
                repaint();
            }
            if (Mode == Era) {
                X11 = e.getX();
                Y11 = e.getY();
                ShapeList.add(new EraserShape(X11, Y11, 15, 15, Color.white));
                repaint();
            }
             // Update mouse coordinates for other drawing modes
			X22 = e.getX();
            Y22 = e.getY();
            repaint();
            Flag = true;
        }
    }

    class Press_Release extends MouseAdapter {
        public void mousePressed(MouseEvent e) {
            // Additional handling for Pencil mode if needed
			if (Mode == Pen) {
            }
            // Additional handling for Eraser mode if needed
			if (Mode == Era) {
            }
            // Store initial mouse coordinates
			X11 = e.getX();
            Y11 = e.getY();
        }

        public void mouseReleased(MouseEvent e) {
            if (Flag) {
               // Check drawing flag and add the appropriate shape to the list
			   switch (Mode) {
                    case Rec:
                        ShapeList.add(new RectangleShape(X11, Y11, X22, Y22, CurrentColor, solid, dottedStroke));
                        break;
                    case Lin:
                        ShapeList.add(new LineShape(X11, Y11, X22, Y22, CurrentColor, dottedStroke));
                        break;
                    case Ova:
                        ShapeList.add(new OvalShape(X11, Y11, X22, Y22, CurrentColor, solid, dottedStroke));
                        break;
                }
                // Reset flag
				Flag = false;
            }
        }
    }
// Abstract class for representing geometric shapes
    abstract class GeoShape {
        int x1, y1, x2, y2;
        Color c;

        public GeoShape(int X1, int Y1, int X2, int Y2, Color C) {
            x1 = X1 ;
            y1 = Y1;
            x2 = X2;
            y2 = Y2;
            c = C ;
        }

        // Abstract method for drawing the shape
		public abstract void drawShape(Graphics g);
    }

 //Concrete Classes (RectangleShape, OvalShape, LineShape, EraserShape, PencilShape):
//Each concrete class represents a specific geometric shape and provides its own implementation of the drawShape method. This allows for the encapsulation of shape-specific details, providing a clear separation of concerns and promoting code reuse   
	class RectangleShape extends GeoShape {
        boolean solid;
        boolean dottedStroke;

        public RectangleShape(int X1, int Y1, int X2, int Y2, Color C, boolean SOLID, boolean DOTTEDSTROKE) {
            super(X1 ,Y1 , X2 , Y2 , C);
            solid = SOLID;
            dottedStroke = DOTTEDSTROKE;
        }

        public void drawShape(Graphics g) {
            int X_Small, Y_Small;
            if (x2 < x1) {
                X_Small = x2;
            } else {
                X_Small = x1;
            }
            if (y2 < y1) {
                Y_Small = y2;
            } else {
                Y_Small = y1;
            }
            if (solid == false) {
                g.setColor(c);
                if (dottedStroke) {
                    drawDottedRectangle(g, X_Small, Y_Small, Math.abs(x2 - x1), Math.abs(y2 - y1));
                } else {
                    g.drawRect(X_Small, Y_Small, Math.abs(x2 - x1), Math.abs(y2 - y1));
                }
            } else {
                g.setColor(c);
                g.fillRect(X_Small, Y_Small, Math.abs(x2 - x1), Math.abs(y2 - y1));
            }
        }

        private void drawDottedRectangle(Graphics g, int x, int y, int width, int height) {
            
            Graphics2D g2d = (Graphics2D) g;
            Stroke originalStroke = g2d.getStroke();
            float[] dashPattern = {5, 5};
            g2d.setStroke(new BasicStroke(1, BasicStroke.CAP_BUTT, BasicStroke.JOIN_MITER, 10, dashPattern, 0));
            g2d.drawRect(x, y, width, height);
            g2d.setStroke(originalStroke);
        }
    }

    class OvalShape extends GeoShape {
        boolean solid;
        boolean dottedStroke;

        public OvalShape(int X1, int Y1, int X2, int Y2, Color C, boolean SOLID, boolean DOTTEDSTROKE) {
            super(X1, Y1, X2 , Y2, C);
            solid = SOLID;
            dottedStroke = DOTTEDSTROKE;
        }

        public void drawShape(Graphics g) {
            int X_Small, Y_Small;
            if (x2 < x1) {
                X_Small = x2;
            } else {
                X_Small = x1;
            }
            if (y2 < y1) {
                Y_Small = y2;
            } else {
                Y_Small = y1;
            }
            if (solid == false) {
                g.setColor(c);
                if (dottedStroke) {
                    drawDottedOval(g, X_Small, Y_Small, Math.abs(x2 - x1), Math.abs(y2 - y1));
                } else {
                    g.drawOval(X_Small, Y_Small, Math.abs(x2 - x1), Math.abs(y2 - y1));
                }
            } else {
                g.setColor(c);
                g.fillOval(X_Small, Y_Small, Math.abs(x2 - x1), Math.abs(y2 - y1));
            }
        }

        private void drawDottedOval(Graphics g, int x, int y, int width, int height) {
            
            Graphics2D g2d = (Graphics2D) g;
            Stroke originalStroke = g2d.getStroke();
            float[] dashPattern = {5, 5};
            g2d.setStroke(new BasicStroke(1, BasicStroke.CAP_BUTT, BasicStroke.JOIN_MITER, 10, dashPattern, 0));
            g2d.drawOval(x, y, width, height);
            g2d.setStroke(originalStroke);
        }
    }
class LineShape extends GeoShape {
    boolean dottedStroke;

    public LineShape(int X1, int Y1, int X2, int Y2, Color C, boolean DOTTEDSTROKE) {
        super(X1, Y1 , X2, Y2, C);
        dottedStroke = DOTTEDSTROKE;
    }

    public void drawShape(Graphics g) {
        if (dottedStroke) {
            drawDottedLine(g, x1, y1, x2, y2);
        } else {
            g.setColor(c);
            g.drawLine(x1, y1, x2, y2);
        }
    }

    private void drawDottedLine(Graphics g, int x1, int y1, int x2, int y2) {
        // Implement the logic for drawing a dotted line
        Graphics2D g2d = (Graphics2D) g;
        Stroke originalStroke = g2d.getStroke();
        float[] dashPattern = {5, 5};
        g2d.setStroke(new BasicStroke(1, BasicStroke.CAP_BUTT, BasicStroke.JOIN_MITER, 10, dashPattern, 0));
        g2d.drawLine(x1, y1, x2, y2);
        g2d.setStroke(originalStroke);
    }
}
    class EraserShape extends GeoShape {
        public EraserShape(int X1, int Y1, int X2, int Y2, Color C) {
            super(X1, Y1 , X2, Y2, C);
        }

        public void drawShape(Graphics g) {
          g.setColor(getBackground());
            g.fillRect(x1, y1, x2, y2);
        }
    }

    class PencilShape extends GeoShape {

        public PencilShape(int X1, int Y1, int X2, int Y2, Color C) {
            super(X1, Y1, X2, Y2 , C);

            x2 = X2;
            y2 = Y2;
        }

        public void drawShape(Graphics g) {
            g.setColor(c);
            g.fillRect(x1, y1, x2, y2);

        }

    }
}
